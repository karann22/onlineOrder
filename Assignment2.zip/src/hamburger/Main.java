package hamburger;

import hamburger.data.Sides;
import hamburger.input.Input;

public class Main {

    public static void main(String[] args) {
        Input.InputMenu();
    }
}
