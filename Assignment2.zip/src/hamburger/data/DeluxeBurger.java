package hamburger.data;

public class DeluxeBurger extends Hamburger {


    public DeluxeBurger(int id, String name, double price, String meat, String bun) {
        super(id, name, price, meat, bun);
    }
}
