package hamburger.data;

public class Sides extends MenuItem {


    public Sides(int id, String name, double price) {
        super(id, name, price);
    }
}
